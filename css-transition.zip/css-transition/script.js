const container = document.getElementById("grid-container");
    for (let i = 1; i <= 60; i++) {
        const gridItem = document.createElement("div");
        gridItem.classList.add("grid-item");
        gridItem.textContent = i;
        container.appendChild(gridItem);
    }
